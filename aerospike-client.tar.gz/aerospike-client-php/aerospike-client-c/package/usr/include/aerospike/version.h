// Version format: MNNPPBBBB
// M: major
// N: minor
// P: patch
// B: build id
#define AEROSPIKE_CLIENT_VERSION 406230000L

extern char* aerospike_client_version;
