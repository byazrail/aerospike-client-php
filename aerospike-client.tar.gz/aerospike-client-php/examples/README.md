# Aerospike PHP Client Examples

The following subdirectories contain example scripts which demonstrate
different aspects of the Aerospike PHP client's API.

